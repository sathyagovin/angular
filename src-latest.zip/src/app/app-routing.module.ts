import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { EditpageComponent } from './editpage/editpage.component';
import {EmpDetailComponent} from './emp-detail/emp-detail.component';
import { CreateEmployeeComponent } from './create-employee/create-employee.component';
const routes: Routes = [
  { path: 'login',component: LoginComponent},
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: 'home',component: HomeComponent},
  { path: 'editpage',component: EditpageComponent},
  { path: 'emp-detail',component: EmpDetailComponent},
  { path: 'create-employee', component: CreateEmployeeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
