import { Component,OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'learnang';
  /*******/
  isLoggedIn:boolean = false;
  /*******/
  constructor(public router: Router) { }
  ngOnInit(): void {
    //this.refreshPage();
  }
  /*******/
  loginMessage($event?:any){
    if($event == "login success"){
      this.isLoggedIn = true;
      this.router.navigateByUrl('/home');
    }
    else{
      this.router.navigateByUrl('/login');
    }
  }
  refreshPage() {
   // this.router.navigateByUrl('/login');
   }
  /*******/
}
