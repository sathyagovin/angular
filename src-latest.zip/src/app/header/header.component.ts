//import { analyzeAndValidateNgModules } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  userName:any;
  constructor() {
    // let getName = localStorage.getItem('userName').split("@");
    let getName = localStorage.getItem('userName')?.split("@")[0];
    let nameGet = getName?.split("@")[0];
    console.log(getName);
    this.userName = getName;
   // this.userName = getName[0];
    //this.userName = getName;
    //email.slice(0, email.indexOf('@'));
   }
   //constructor() { }
  ngOnInit(): void {
  }

}
