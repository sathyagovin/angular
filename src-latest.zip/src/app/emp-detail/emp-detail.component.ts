import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { Router } from '@angular/router';
import { Tablelist } from '../model/tablelist';
import { SharedService } from '../services/shared.service';
@Component({
  selector: 'app-emp-detail',
  templateUrl: './emp-detail.component.html',
  styleUrls: ['./emp-detail.component.css']
})
export class EmpDetailComponent implements OnInit {
  @Output() editEvent = new EventEmitter<any>();
  public togglePhone: boolean = true;
  public toggleEmail: boolean = true;
  visible:boolean = false;
  tablelist = new Tablelist();
  Phone: any;
  Email: any;
  Type: any;
  constructor(public router: Router,public sharedService: SharedService) { }

  ngOnInit(): void {
    this.editApp();
  }
  editApp() {
    this.sharedService.existData.subscribe(data => this.tablelist.result = data);
    
      this.tablelist.sapid = this.tablelist.result.sapid;
      this.tablelist.name = this.tablelist.result.name;
      this.tablelist.org = this.tablelist.result.org;
      this.tablelist.phone = this.tablelist.result.phone;
      this.tablelist.email = this.tablelist.result.email;
	    this.tablelist.checked = this.tablelist.result.checked;
      this.tablelist.type = this.tablelist.result.type;
	  /* this.tablelist.subModuleName = this.tablelist.inputSource.subModule.subModuleName;
	  this.tablelist.selectedRightType = this.tablelist.inputSource.subModule.selectedRightType; */
    
  }
  savedata(){
    localStorage.setItem('Phone', this.tablelist.phone);
    localStorage.setItem('Email', this.tablelist.email);
    localStorage.setItem('Type', this.tablelist.type);
    let getPhone = localStorage.getItem('Phone');
    let getEmail = localStorage.getItem('Email');
    let getCheckedType = localStorage.getItem('Type');
    this.Phone = getPhone;
    this.Email = getEmail;
    this.Type = getCheckedType;
    this.visible = !this.visible
    this.router.navigateByUrl('/home');
    this.editEvent.emit("phone and email updated successfully");
}
updatefields(){
    this.togglePhone = false;
    this.toggleEmail = false;
    
  }
  disablefields(){
    this.togglePhone = true;
    this.toggleEmail = true;
 
  }
  // updateemail(){
    
  // }
}
