import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EditpageService } from '../services/editpage.service';
import { Tablelist } from '../model/tablelist';
@Component({
  selector: 'app-editpage',
  templateUrl: './editpage.component.html',
  styleUrls: ['./editpage.component.css']
})
export class EditpageComponent implements OnInit {
  // tablelist = new Tablelist();
  tablelist: Tablelist[] = [];
  cols: any[] = [];
  // @Input()
  // item = '';
  // label!: string;
  //   @Input()
  // value!: string;
  // @Input() slno: any;
  // @Input() name: any;
  //@Output() messageEvent = new EventEmitter<any>();
  // @Input()
  // name!:any;
  //@Input() name:Tablelist = new Tablelist();

  constructor(private editpageService: EditpageService) { }

  ngOnInit(): void {
    this.editpageService.getProductsSmall().then(data => this.tablelist = data);

        this.cols = [
            { field: 'sapid', header: 'SapId' },
            { field: 'name', header: 'Name' },
            { field: 'org', header: 'Organization' }
        ];
  }
 
}
