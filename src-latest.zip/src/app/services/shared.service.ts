import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SharedService {
  private modifydata = new BehaviorSubject('');
  private transferdata = new BehaviorSubject('');
  existData = this.modifydata.asObservable();
  
  constructor() { }

  editexistApp(data:any){
    this.modifydata.next(data)
  }
  solutionName(data: any) {
    this.transferdata.next(data)
  }
  // addData(data:any){

  // }
  
}
