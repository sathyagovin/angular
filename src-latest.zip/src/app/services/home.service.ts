import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

// import { BehaviorSubject } from 'rxjs';
//import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class HomeService {
  
  private readonly PRIMENGTABLE='assets/data/tablelist.json';
   
  constructor(private http: HttpClient) { }

  getTableList() {
    return this.http.get(this.PRIMENGTABLE);
  }

}
