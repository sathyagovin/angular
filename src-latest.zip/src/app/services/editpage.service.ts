import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Tablelist } from '../model/tablelist';
@Injectable({
  providedIn: 'root'
})
export class EditpageService {

  constructor(private http: HttpClient) { }
  getProductsSmall() {
    return this.http.get<any>('assets/data/tablelistedit.json')
    .toPromise()
    .then(res => <Tablelist[]>res.data)
    .then(data => { return data; });
}
}
