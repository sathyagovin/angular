import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { Router } from '@angular/router';

import { Login } from '../model/login';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  password: any;
 /******* */
  @Output() loginEvent = new EventEmitter<any>();
  login: Login = {
    email: '',
    password: ''
  };
  constructor(private router: Router) { }
  
  ngOnInit(): void {
  }
  /******* */
  onSubmit(value: any) {
    localStorage.setItem('userName', this.login.email);
    localStorage.setItem('password', this.login.password);
    this.password = this.login.password;
    this.loginEvent.emit("login success");
  }
}
