export class Tablelist {
  id?:string;
  tablevalues:any;
  sapid: any;
  name: any;
  org: any;
  phone:any;
  email:any;
  type:any;
  checked: any;
  selectedApp: any;
  selectedAppValue:any;
  i: any;
  value: any;
  inputSource: any;
  result:any;
  navigateVlaue: any;
  testform:any;
  
  }