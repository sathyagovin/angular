import { Component, Output,EventEmitter,OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Tablelist } from '../model/tablelist';
import { SharedService } from '../services/shared.service';
import {MessageService} from 'primeng/api';
import { HomeService } from '../services/home.service';
import { HttpErrorResponse } from '@angular/common/http';
//import { ConfirmationService } from 'primeng/api';
@Component({
  selector: 'app-create-employee',
  templateUrl: './create-employee.component.html',
  styleUrls: ['./create-employee.component.css'],
  providers: [MessageService]
})
export class CreateEmployeeComponent implements OnInit {
  tablelist = new Tablelist();
  submitted: boolean = false;
 
 @Output() newItemEvent = new EventEmitter<string>();

  constructor(public router: Router,public sharedService: SharedService, private messageService: MessageService,
    //private confirmationService: ConfirmationService
    public homeService: HomeService
    ) { }

  ngOnInit(): void {
   // this.getAppList();
  }
  // getAppList() {    
    
  //   this.homeService.getTableList().subscribe((data: any) => {
  //   this.tablelist.tablevalues = data; 
  //   //console.log(data)    
    
  //   },
  //     (error: HttpErrorResponse) => {
        
  //       alert("Error while loading data");       
  //     });
  // }
  // addNewItem(value: string) {
  //   this.newItemEvent.emit(value);
  //   this.router.navigateByUrl('/home');
  // }
  // addItem(newItem: string) {
  //   this.tablelist.tablevalues.push(newItem);
  // }
  
  upload() {
    //this.submitted = true;
  //   if (this.tablelist.sapid) {
  //     this.tablelist.tablevalues[this.findIndexById(this.tablelist.sapid)] = this.tablelist;                
  //     this.messageService.add({severity:'success', summary: 'Successful', detail: 'Product Updated', life: 3000});
  // }
  // else {
  //     this.tablelist.id = this.createId();
  //     //this.tablelist.image = 'product-placeholder.svg';
  //     this.tablelist.tablevalues.push(this.tablelist);
  //     this.messageService.add({severity:'success', summary: 'Successful', detail: 'Product Created', life: 3000});
  // }
   // this.sharedService.solutionName(this.tablelist.selectedAppValue);
    
    //this.alertService.success("New application is successfully created");
   // this.tablelist.navigateVlaue = '/home';
   
    // this.router.navigateByUrl('/home');
    // this.messageEvent.emit("strnavlinkchanged");
    
    //this.tablelist.navigateVlaue = '';
    //this.messageEvent.emit("");
  }

//   findIndexById(sapid: string): number {
//     let index = -1;
//     for (let i = 0; i < this.tablelist.tablevalues.length; i++) {
//         if (this.tablelist.tablevalues[i].sapid === sapid) {
//             index = i;
//             break;
//         }
//     }

//     return index;
// }
// createId(): string {
//   let sapid = '';
//   var chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
//   for ( var i = 0; i < 5; i++ ) {
//     sapid += chars.charAt(Math.floor(Math.random() * chars.length));
//   }
//   return sapid;
// }
  openNew() {
    this.tablelist.sapid = this.tablelist.inputSource.sapid;
    this.tablelist.name = this.tablelist.inputSource.name;
    this.tablelist.org = this.tablelist.inputSource.org;
    this.tablelist.phone = this.tablelist.inputSource.phone;
    this.tablelist.email = this.tablelist.inputSource.email;
    //this.submitted = false;
    //this.productDialog = true;
}
}
