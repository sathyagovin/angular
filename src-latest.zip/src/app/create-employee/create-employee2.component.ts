import { Component, Output,EventEmitter,OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Tablelist } from '../model/tablelist';
import { SharedService } from '../services/shared.service';
import {MessageService} from 'primeng/api';
import { HomeService } from '../services/home.service';
import { HttpErrorResponse } from '@angular/common/http';
//import { ConfirmationService } from 'primeng/api';
export interface Tile {
  color: string;
  cols: number;
  rows: number;
  text: string;
}
@Component({
  selector: 'app-create-employee',
  templateUrl: './create-employee.component.html',
  styleUrls: ['./create-employee.component.css'],
  providers: [MessageService]
})
export class CreateEmployeeComponent {
  tiles: Tile[] = [
    {text: 'One', cols: 4, rows: 1, color: 'lightblue'},
    {text: 'Two', cols: 3, rows: 1, color: 'lightgreen'},
    {text: 'Three', cols: 1, rows: 1, color: 'lightpink'},
    {text: 'Four', cols: 3, rows: 1, color: '#DDBDF1'},
  ];
}

