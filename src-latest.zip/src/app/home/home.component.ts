import { Component,Output,EventEmitter,Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HomeService } from '../services/home.service';
import { SharedService } from '../services/shared.service';
import { Tablelist } from '../model/tablelist';
import { HttpErrorResponse } from '@angular/common/http';
import {MessageService} from 'primeng/api';
import { ConfirmationService } from 'primeng/api';
import { filter, map } from 'rxjs/operators';

@Component({//decorator
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  providers: [MessageService,ConfirmationService],
  styles: [`
      :host ::ng-deep .p-cell-editing {
          padding-top: 0 !important;
          padding-bottom: 0 !important;
      }
  `],
  
})
export class HomeComponent implements OnInit {
  name:string="Sathya";
  changeName(event:Event){
    console.log(event);
    this.name = (<HTMLInputElement>event.target).value;
  }
  // Phone:any;
   tablelist = new Tablelist();
   tablelistvalue: any;

   selectedCustomer:Tablelist = new Tablelist();
   @Output() messageEvent = new EventEmitter<any>();
  //  @Input() 
  //  Phone:any;
  //   Email:any;
  visible:boolean = false;
  Phone: any;
  Email: any;
  Type:any;
  constructor(public router: Router,public homeService: HomeService, public sharedService: SharedService, private messageService: MessageService, private confirmationService: ConfirmationService) 
  { 
    let getPhone = localStorage.getItem('Phone');
    let getEmail = localStorage.getItem('Email');
    let getCheckedType = localStorage.getItem('Type');
    this.Phone = getPhone;
    this.Email = getEmail;
    this.Type = getCheckedType;
    this.visible = !this.visible;
  }

  ngOnInit(): void {
    this.getAppList();
  }
  getAppList() {    
    
    this.homeService.getTableList().subscribe((data: any) => {
    this.tablelist.tablevalues = data; 
    //console.log(data)    
    // let getPhone = localStorage.getItem('Phone');
    
    // console.log(getPhone);
    
    },
      (error: HttpErrorResponse) => {
        
        alert("Error while loading data");       
      });
  }
  
  editDetails(i: any, value: any) {
    this.tablelist.selectedApp = i;
   // this.tablelist.selectedAppValue = value;
    const selectedEditApp = value;
    this.sharedService.editexistApp(selectedEditApp);
    // console.log(i);
    // console.log(value);
   
    this.router.navigateByUrl('/emp-detail');
    this.messageEvent.emit("navlinkchanged");
  }
  createApp(){
    this.router.navigateByUrl('/create-employee');
    this.messageEvent.emit("navlinkchanged");
    this.sharedService.editexistApp("");
  }
  
  deleteProduct(tablelist: Tablelist) {
    this.confirmationService.confirm({
        message: 'Are you sure you want to delete ' + tablelist.name + '?',
        header: 'Confirm',
        icon: 'pi pi-exclamation-triangle',
        accept: () => {
            this.tablelist.tablevalues = this.tablelist.tablevalues.filter((val: { sapid: any; }) => val.sapid !== tablelist.sapid);
            
            //this.tablelist = {};
            this.messageService.add({severity:'success', summary: 'Successful', detail: 'Product Deleted', life: 3000});
        }
    });
}
  // newApp() {
  //   this.router.navigateByUrl('/emp-detail');
  //   this.messageEvent.emit("navlinkchanged");
  //   this.sharedService.editexistApp("");
  // }
 
}
